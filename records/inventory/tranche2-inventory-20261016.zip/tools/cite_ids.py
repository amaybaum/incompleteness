"""Read-only: every CI run and job id cited in a commit's tracked text, by the off-main audit's own rule R.

Same file set, same regexes, same file classes as verification/audits/evidence-retention/audit/offmain_audit.py.
Usage: cite_ids.py COMMIT OUT.json  (run from a clone)."""
import collections, json, re, subprocess, sys
MAIN, OUT = sys.argv[1], sys.argv[2]
def run(*a, inp=None):
    return subprocess.run(a, input=inp, capture_output=True, text=True, check=False).stdout
def show(path):
    return subprocess.run(['git', 'show', '%s:%s' % (MAIN, path)], capture_output=True).stdout
all_files = [f for f in run('git', 'ls-tree', '-r', '--name-only', MAIN).split('\n') if f]
skip_ext = ('.pdf', '.tex', '.olean', '.png', '.jpg', '.gz', '.zip', '.ilean')
files = [f for f in all_files if not f.endswith(skip_ext)]
record_dirs = []
for r in [f for f in all_files if f.startswith('verification/receipts/') and f.endswith('.json')]:
    for b in json.loads(show(r)).get('control_plane_blobs', []):
        m = re.search(r'```v3-round\n(.*?)```', show(b['path']).decode('utf-8'), re.S)
        d = m and re.search(r'^record-directory (\S+)', m.group(1), re.M)
        if d:
            record_dirs.append(d.group(1).rstrip('/') + '/')
legacy = set(json.loads(show('verification/infrastructure/legacy-records.json'))['records'])
def klass(path):
    if path.startswith('verification/receipts/'):
        return 'receipt'
    if any(path.startswith(d) for d in record_dirs):
        return 'native-record'
    if path in legacy:
        return 'legacy-record'
    return 'mutable'
runre = re.compile(r'(?<!\d)(3\d{10}|1\d{11})(?!\d)')
ctxre = re.compile(r'\brun|\bjob|actions/', re.I)
refs = []
for f in files:
    try:
        txt = show(f).decode('utf-8')
    except UnicodeDecodeError:
        continue
    for i, line in enumerate(txt.split('\n'), 1):
        if ctxre.search(line):
            for m in runre.finditer(line):
                x = m.group(1)
                refs.append({'id': x, 'kind': 'run' if len(x) == 11 else 'job', 'file': f, 'line': i,
                             'class': klass(f), 'text': line.strip()[:240]})
json.dump({'commit': MAIN, 'refs': refs}, open(OUT, 'w'), indent=1)
locs = {(r['file'], r['line']) for r in refs}
tally = collections.Counter(klass(f) for f, _ in locs)
print('%d citations at %d file:line locations in %d files (%s); %d distinct run ids, %d distinct job ids' % (
    len(refs), len(locs), len({f for f, _ in locs}), ', '.join('%s %d' % kv for kv in sorted(tally.items())),
    len({r['id'] for r in refs if r['kind'] == 'run'}), len({r['id'] for r in refs if r['kind'] == 'job'})))
