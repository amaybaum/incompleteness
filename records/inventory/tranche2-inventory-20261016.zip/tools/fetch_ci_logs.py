#!/usr/bin/env python3
"""Download the complete log archive of every cited CI run, in priority order, and record what was received.

Run it on a machine where `gh` is logged in to an account that can read amaybaum/incompleteness:

    python3 -I fetch_ci_logs.py --inventory inventory-runs.csv --out ci-logs
    python3 -I fetch_ci_logs.py --inventory inventory-runs.csv --out ci-logs --tier A      # one tier only
    python3 -I fetch_ci_logs.py --self-test                                                # no network

For each run it calls `gh api repos/<repo>/actions/runs/<id>/logs` (the zip GitHub serves for the whole run),
writes <out>/runs/<id>.zip, and appends one JSON line to <out>/fetch-log.jsonl:
  the run id, tier, head sha and run creation time from the inventory;
  the outcome: archived, unavailable (the host answered with an error, e.g. 404 or 410, quoted), or failed
  (the command could not complete);
  for an archived run, the zip's size and sha256, and every member's name, size and sha256.
It never deletes or overwrites a stored zip: a run already archived is skipped, so an interrupted pass resumes.
`--manifest` then writes <out>/manifest.json from the stored zips and the fetch log, re-hashing every zip.

The scan (`--scan`) looks through the stored logs for text shaped like credentials and reports file, member and
line number only, never the matched text. GitHub masks registered secrets as ***, so a hit is something
unregistered that needs a look before any log is published. A clean scan is a scan, not a guarantee.

Priority: runs no R1 entry covers before covered ones; then tier A, B, J, C; within that, oldest first. Every
log expires at the same age under one retention setting, so oldest-first is the expiry order.
"""
import argparse, csv, datetime as dt, hashlib, io, json, os, re, subprocess, sys, tempfile, zipfile

REPO = 'amaybaum/incompleteness'
ORDER = {'A': 0, 'B': 1, 'J': 2, 'C': 3}
SECRETS = [re.compile(p) for p in (
    r'gh[pousr]_[A-Za-z0-9]{36,}', r'github_pat_[A-Za-z0-9_]{50,}', r'AKIA[0-9A-Z]{16}', r'-----BEGIN [A-Z ]*PRIVATE KEY-----',
    r'xox[abprs]-[A-Za-z0-9-]{10,}', r'(?i)\b(authorization|bearer)\b[:= ]+[A-Za-z0-9._~+/-]{20,}', r'sk-[A-Za-z0-9]{32,}')]


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec='seconds')


def sha(b):
    return hashlib.sha256(b).hexdigest()


def load(inventory):
    rows = list(csv.DictReader(open(inventory, newline='')))
    for r in rows:
        assert r['run_id'].isdigit(), r['run_id']
    rows.sort(key=lambda r: (r['r1_entry'] != '', ORDER[r['tier']], r['created_at']))
    return rows


def done(out):
    p = os.path.join(out, 'fetch-log.jsonl')
    seen = {}
    if os.path.exists(p):
        for line in open(p):
            e = json.loads(line)
            seen[e['run_id']] = e
    return seen


def members(blob):
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        return [{'name': i.filename, 'size': i.file_size, 'sha256': sha(z.read(i))} for i in z.infolist() if not i.is_dir()]


def fetch(rows, out, gh, tiers):
    os.makedirs(os.path.join(out, 'runs'), exist_ok=True)
    seen = done(out)
    log = open(os.path.join(out, 'fetch-log.jsonl'), 'a')
    n = {'archived': 0, 'unavailable': 0, 'failed': 0, 'skipped': 0}
    for r in rows:
        rid = r['run_id']
        if tiers and r['tier'] not in tiers:
            continue
        dest = os.path.join(out, 'runs', rid + '.zip')
        if os.path.exists(dest) and seen.get(rid, {}).get('outcome') == 'archived':
            n['skipped'] += 1
            continue
        if os.path.exists(dest):  # stored by a pass interrupted before it logged; record it from the file, never refetch over it
            blob = open(dest, 'rb').read()
            e = {'run_id': rid, 'tier': r['tier'], 'r1_entry': r['r1_entry'], 'head_sha': r['head_sha'], 'created_at': r['created_at'],
                 'requested_at': None, 'outcome': 'archived', 'bytes': len(blob), 'sha256': sha(blob), 'members': members(blob),
                 'detail': 'recorded from a zip an interrupted pass stored without logging it'}
            log.write(json.dumps(e) + '\n'); log.flush(); n['archived'] += 1
            continue
        base = {'run_id': rid, 'tier': r['tier'], 'r1_entry': r['r1_entry'], 'head_sha': r['head_sha'],
                'created_at': r['created_at'], 'requested_at': now()}
        try:
            p = subprocess.run(gh + ['api', 'repos/%s/actions/runs/%s/logs' % (REPO, rid)], capture_output=True, timeout=600)
        except Exception as ex:  # the command did not complete
            e = {**base, 'outcome': 'failed', 'detail': repr(ex)}
        else:
            if p.returncode == 0 and zipfile.is_zipfile(io.BytesIO(p.stdout)):
                assert not os.path.exists(dest), dest  # never overwrite a stored zip
                tmp = dest + '.part'
                open(tmp, 'wb').write(p.stdout)
                os.replace(tmp, dest)
                e = {**base, 'outcome': 'archived', 'bytes': len(p.stdout), 'sha256': sha(p.stdout), 'members': members(p.stdout)}
            elif p.returncode != 0:
                err = p.stderr.decode('utf-8', 'replace').strip()
                e = {**base, 'outcome': 'unavailable' if re.search(r'HTTP (404|410)', err) else 'failed', 'detail': err[:500]}
            else:
                e = {**base, 'outcome': 'failed', 'detail': 'the response was not a zip (%d bytes)' % len(p.stdout)}
        log.write(json.dumps(e) + '\n')
        log.flush()
        n[e['outcome']] += 1
        print(rid, r['tier'], e['outcome'], e.get('bytes', ''), file=sys.stderr)
    return n


def manifest(out):
    seen = done(out)
    ents, bad = [], []
    for rid, e in sorted(seen.items()):
        if e['outcome'] == 'archived':
            blob = open(os.path.join(out, 'runs', rid + '.zip'), 'rb').read()
            if sha(blob) != e['sha256'] or members(blob) != e['members']:
                bad.append(rid)
        ents.append(e)
    m = {'repository': REPO, 'written_at': now(), 'runs': ents,
         'counts': {k: sum(1 for e in ents if e['outcome'] == k) for k in ('archived', 'unavailable', 'failed')},
         'rehash_mismatches': bad,
         'what_this_is': 'the log zips GitHub served for these runs, byte for byte as received, with their digests; '
                         'a log the host no longer serves is recorded as unavailable with the host\'s answer'}
    json.dump(m, open(os.path.join(out, 'manifest.json'), 'w'), indent=1)
    return m


def scan(out):
    hits = []
    for f in sorted(os.listdir(os.path.join(out, 'runs'))):
        if not f.endswith('.zip'):
            continue
        with zipfile.ZipFile(os.path.join(out, 'runs', f)) as z:
            for i in z.infolist():
                for k, line in enumerate(z.read(i).decode('utf-8', 'replace').split('\n'), 1):
                    for rx in SECRETS:
                        if rx.search(line):
                            hits.append({'zip': f, 'member': i.filename, 'line': k, 'pattern': rx.pattern})
    json.dump(hits, open(os.path.join(out, 'scan.json'), 'w'), indent=1)
    return hits


def self_test():
    """Drives fetch, resume, manifest and scan through a stub `gh` that serves three cases."""
    with tempfile.TemporaryDirectory() as d:
        stub = os.path.join(d, 'gh')
        open(stub, 'w').write(r'''#!/usr/bin/env python3
import io, sys, zipfile
rid = sys.argv[2].split('/')[-2]
if rid == '2':
    sys.stderr.write('gh: Not Found (HTTP 404)\n'); sys.exit(1)
if rid == '3':
    sys.stderr.write('connection reset\n'); sys.exit(1)
b = io.BytesIO()
with zipfile.ZipFile(b, 'w') as z:
    z.writestr('Mathlib bridge/6_Release gate.txt', 'gate ok\n' + ('token ghp_' + 'a' * 36 if rid == '4' else '') + '\n')
sys.stdout.buffer.write(b.getvalue())
''')
        os.chmod(stub, 0o755)
        inv = os.path.join(d, 'inv.csv')
        with open(inv, 'w', newline='') as fh:
            w = csv.writer(fh)
            w.writerow(['run_id', 'r1_entry', 'tier', 'created_at', 'head_sha'])
            w.writerows([['1', '', 'B', '2026-09-20', 'a'], ['2', '', 'A', '2026-09-21', 'b'], ['3', '', 'A', '2026-09-19', 'c'],
                         ['4', 'ci-4', 'A', '2026-09-18', 'd']])
        out = os.path.join(d, 'out')
        rows = load(inv)
        assert [r['run_id'] for r in rows] == ['3', '2', '1', '4'], 'priority order'
        n = fetch(rows, out, [stub], None)
        assert n == {'archived': 2, 'unavailable': 1, 'failed': 1, 'skipped': 0}, n
        n2 = fetch(rows, out, [stub], None)
        assert n2['skipped'] == 2 and n2['archived'] == 0, ('resume', n2)
        lines = open(os.path.join(out, 'fetch-log.jsonl')).read().split('\n')
        open(os.path.join(out, 'fetch-log.jsonl'), 'w').write('\n'.join(l for l in lines if '"run_id": "4"' not in l))
        n3 = fetch(rows, out, [stub], {'A'})
        assert n3['archived'] == 1 and 'interrupted' in done(out)['4']['detail'], ('interrupted pass', n3)
        m = manifest(out)
        assert m['counts'] == {'archived': 2, 'unavailable': 1, 'failed': 1} and not m['rehash_mismatches'], m['counts']
        with open(os.path.join(out, 'runs', '1.zip'), 'ab') as fh:
            fh.write(b'x')
        assert manifest(out)['rehash_mismatches'] == ['1'], 'a changed zip is caught'
        hits = scan(out)
        assert [h['zip'] for h in hits] == ['4.zip'] and 'ghp_' not in json.dumps(hits).replace('gh[pousr]_', ''), hits
        assert fetch(rows, out, [stub], {'C'}) == {'archived': 0, 'unavailable': 0, 'failed': 0, 'skipped': 0}, 'tier filter'
    print('self-test: OK (order, three outcomes, resume, interrupted pass, re-hash, scan without echo, tier filter)')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--inventory'); ap.add_argument('--out'); ap.add_argument('--tier', action='append')
    ap.add_argument('--manifest', action='store_true'); ap.add_argument('--scan', action='store_true')
    ap.add_argument('--self-test', action='store_true'); ap.add_argument('--gh', default='gh')
    a = ap.parse_args()
    if a.self_test:
        self_test(); sys.exit(0)
    if a.manifest:
        print(json.dumps(manifest(a.out)['counts'])); sys.exit(0)
    if a.scan:
        h = scan(a.out); print('%d possible credential lines; see scan.json' % len(h)); sys.exit(1 if h else 0)
    print(json.dumps(fetch(load(a.inventory), a.out, [a.gh], set(a.tier) if a.tier else None)))
