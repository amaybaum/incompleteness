"""Ranges of runs cited by their two endpoints ("<id> … <id>", "<id>–<id>", "<id> to <id>", "<id> through <id>") at a commit.
The inner runs of a range are the listed runs strictly between the endpoints whose head branch is the endpoints' own.
Usage: scan_ranges.py COMMIT INV_DIR OUT.json"""
import json, re, subprocess, sys
C, D, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
G = ['git', '-C', '/home/user/incompleteness']
runs = json.load(open(D + '/all-runs.json'))
skip = ('.pdf', '.tex', '.olean', '.png', '.jpg', '.gz', '.zip', '.ilean', '.bundle')
files = [f for f in subprocess.run(G + ['ls-tree', '-r', '--name-only', C], capture_output=True, text=True, check=True).stdout.split('\n') if f and not f.endswith(skip)]
ID = r'(?<![0-9A-Za-z.])(3\d{10})(?![0-9A-Za-z])'
rx = re.compile(ID + r'`?\s*(?:…|\.\.\.|–|—|-|to|through)\s*`?' + ID)
out = []
for f in files:
    t = subprocess.run(G + ['show', C + ':' + f], capture_output=True).stdout.decode('utf-8', 'replace')
    for i, line in enumerate(t.split('\n'), 1):
        for m in rx.finditer(line):
            a, b = m.group(1), m.group(2)
            if a not in runs or b not in runs or int(a) >= int(b):
                out.append({'location': f'{f}:{i}', 'endpoints': [a, b], 'rejected': 'an endpoint is not a listed run, or the order is reversed'})
                continue
            br = runs[a]['head_branch']
            inner = sorted(k for k, v in runs.items() if int(a) < int(k) < int(b) and v['head_branch'] == br)
            others = sorted(k for k, v in runs.items() if int(a) < int(k) < int(b) and v['head_branch'] != br)
            out.append({'location': f'{f}:{i}', 'endpoints': [a, b], 'head_branch': br, 'same_branch_endpoints': runs[b]['head_branch'] == br,
                        'inner_runs': inner, 'other_branch_runs_between': len(others), 'text': line.strip()[:200]})
res = {'commit': C, 'rule': __doc__.split('\n')[0], 'ranges': [r for r in out if 'inner_runs' in r and r['same_branch_endpoints']],
       'rejected': [r for r in out if 'inner_runs' not in r or not r['same_branch_endpoints']]}
json.dump(res, open(OUT, 'w'), indent=1)
for r in out: print(r['location'], r['endpoints'], len(r.get('inner_runs', [])), r.get('same_branch_endpoints'), r.get('rejected', ''))
