"""Ids of rule-R shape on lines that fail rule R's context test, at a commit.
A run-shaped id counts when it is in the run listing; a job-shaped id is reported for a host check.
Ids inside a longer alphanumeric token, or after a decimal point, are excluded. Usage: scan_outside.py COMMIT INV_DIR OUT.json"""
import json, re, subprocess, sys, collections
C, D, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
G = ['git', '-C', '/home/user/incompleteness']
runs = set(json.load(open(D + '/all-runs.json')))
rule = {c['id'] for c in json.load(open(D + '/cites-clean.json'))['refs']}
skip = ('.pdf', '.tex', '.olean', '.png', '.jpg', '.gz', '.zip', '.ilean', '.bundle')
files = [f for f in subprocess.run(G + ['ls-tree', '-r', '--name-only', C], capture_output=True, text=True, check=True).stdout.split('\n') if f and not f.endswith(skip)]
ctx = re.compile(r'\brun|\bjob|actions/', re.I)
idr = re.compile(r'(?<![0-9A-Za-z.])(3\d{10}|1\d{11})(?![0-9A-Za-z])')
hits = collections.defaultdict(list)
for f in files:
    t = subprocess.run(G + ['show', C + ':' + f], capture_output=True).stdout.decode('utf-8', 'replace')
    for i, line in enumerate(t.split('\n'), 1):
        if ctx.search(line):
            continue
        for m in idr.finditer(line):
            hits[m.group(1)].append({'location': f'{f}:{i}', 'text': line.strip()[:160]})
res = {'commit': C, 'rule': 'ids of rule-R shape on lines failing its context test, not inside a longer alphanumeric token and not the fractional digits of a decimal',
       'runs_new': {}, 'runs_also_rule_r': {}, 'job_shaped': {}, 'other_count': 0}
for k, v in sorted(hits.items()):
    if len(k) == 11 and k in runs:
        if k in rule: res['runs_also_rule_r'][k] = v
        else: res['runs_new'][k] = v
    elif len(k) == 12:
        res['job_shaped'][k] = {'also_rule_r': k in rule, 'locations': v}
    else:
        res['other_count'] += 1
json.dump(res, open(OUT, 'w'), indent=1)
print('new runs', len(res['runs_new']), '| runs also in rule R', len(res['runs_also_rule_r']),
      '| job-shaped', len(res['job_shaped']), '(new', sum(1 for j in res['job_shaped'].values() if not j['also_rule_r']), ') | other', res['other_count'])
