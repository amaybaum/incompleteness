"""Tranche-2 inventory (read-only). Every CI run and job id cited in main's tracked text at the audit base,
with four evidence states kept separate:
  1 metadata   the run is in the repository's run listing (live), and whether R1 archived its run record;
  2 logs       the run's logs are retrievable now (a logs URL is served), or not, or the request failed;
  3 bytes      whether log bytes are preserved in main with a verified hash (raw), or only an expected result
               derived from the log, or nothing;
  4 commit     on-main (durable); branch-only (reachable from a branch, which is not durable); tag-only (reachable from a
               tag and no branch); pull-ref-only (reachable only from a pull request's head ref); host-unreferenced
               (reachable from no ref; the host still served it by sha when checked); absent. Refs are the host's, read
               with git ls-remote (host-refs.txt), not the clone's remote-tracking refs, which can be stale.
A successful logs request establishes availability, not preservation.
Inputs in INV_DIR: cites-fc5abade.json (audit rule R), cites-clean.json (hex fragments excluded), outside.json (ids
of rule-R shape on lines rule R's context test skips), all-runs.json, run-logs.json and run-logs-extra.json, jobs.json
and jobs-outside.json, fetch-by-sha.json, host-refs.txt and host-refs.time; R1's manifest is read from MAIN.  Usage: build_inventory.py INV_DIR REPO_DIR MAIN"""
import csv, datetime as dt, json, os, subprocess, sys, collections
inv, repo, MAIN = sys.argv[1], sys.argv[2], sys.argv[3]
L = lambda n: json.load(open(os.path.join(inv, n)))
raw_refs, refs = L('cites-fc5abade.json')['refs'], L('cites-clean.json')
excluded, refs = refs['excluded_hex_fragments'], refs['refs']
runs, logs, jobs = L('all-runs.json'), {**L('run-logs.json'), **L('run-logs-extra.json')}, {**L('jobs.json'), **L('jobs-outside.json')}
outside, fetched = L('outside.json'), L('fetch-by-sha.json')
HOST_TIME = open(os.path.join(inv, 'host-refs.time')).read().strip()
A = 'verification/audits/evidence-retention/'
def git(*a):
    return subprocess.run(['git', '-C', repo, *a], capture_output=True, text=True)
man = json.loads(git('show', '%s:%smanifest.json' % (MAIN, A)).stdout)
NOW = dt.datetime.now(dt.timezone.utc)
TIER_RULE = ('The highest-ranking citing line decides. A: cited in at least one result note, receipt or certificate; '
             'B: otherwise cited in at least one preregistration or amendment; J: cited only through one of its jobs; '
             'C: cited only elsewhere. Within a tier, oldest first.')
# ---- R1 coverage, entry by entry
ci_entries, raw_runs, derived_runs, raw_jobs, archived_meta, derived_jobs = set(), {}, set(), {}, set(), set()
for e in man['entries']:
    if e['id'].startswith('ci-'):
        ci_entries.add(e['id'][3:]); archived_meta.add(e['id'][3:])
    for f in e['files']:
        p = f['path']
        if p.endswith('.json') and not p.endswith('manifest.json'):
            d = json.loads(git('show', '%s:%s%s' % (MAIN, A, p)).stdout or '{}')
            run = d.get('run') if isinstance(d.get('run'), dict) else d
            rid = str(run.get('id')) if isinstance(run, dict) and run.get('id') else None
            if rid:
                derived_runs.add(rid)
                if os.path.basename(p) == 'results.json' and run.get('job_id'):
                    derived_jobs.add(str(run['job_id']))
                if os.path.basename(p).startswith('run-'):
                    archived_meta.add(rid)
                if run.get('job_id') and e['id'].startswith('bg3'):
                    log = next((g for g in e['files'] if g['path'].endswith('.log')), None)
                    if log:
                        raw_runs[rid] = raw_jobs[str(run['job_id'])] = {
                            'path': A + log['path'], 'sha256': log['sha256'], 'kind': 'the complete design-run log' if 'design-' in log['path'] else 'the served tail of the job log'}
covered = ci_entries | derived_runs
def role(f):
    b = os.path.basename(f)
    if f.startswith('verification/receipts/'): return 'receipt'
    if f.startswith('verification/certificates/'): return 'certificate'
    if '/amendments/' in f: return 'amendment'
    if b.startswith('result'): return 'result'
    if b.startswith('preregistration'): return 'preregistration'
    return 'other'
# the host's refs, mirrored into a scratch repository that borrows the clone's objects; pull merge refs are the host's
# synthetic test merges and are left out
mirror = os.path.join(inv, 'hostrefs.git')
if not os.path.isdir(mirror):
    subprocess.run(['git', 'init', '-q', '--bare', mirror], check=True)
    open(os.path.join(mirror, 'objects', 'info', 'alternates'), 'w').write(os.path.join(repo, '.git', 'objects') + '\n')
    upd = ''.join('create refs/host/%s %s\n' % (ref[5:], sha) for sha, ref in (l.split('\t') for l in open(os.path.join(inv, 'host-refs.txt')).read().split('\n') if l)
                  if ref.startswith(('refs/heads/', 'refs/tags/')) or (ref.startswith('refs/pull/') and ref.endswith('/head')))
    subprocess.run(['git', '-C', mirror, 'update-ref', '--stdin'], input=upd, text=True, check=True)
def host_contains(sha):
    out = subprocess.run(['git', '-C', mirror, 'for-each-ref', '--contains', sha, '--format=%(refname)', 'refs/host/'],
                         capture_output=True, text=True, check=True).stdout.split()
    return ([r[len('refs/host/heads/'):] for r in out if r.startswith('refs/host/heads/')],
            [r[len('refs/host/tags/'):] for r in out if r.startswith('refs/host/tags/')],
            [r[len('refs/host/'):] for r in out if r.startswith('refs/host/pull/')])
_reach = {}
def commit_state(sha):
    if not sha: return {'state': 'unknown', 'branches': []}
    if sha in _reach: return _reach[sha]
    if git('cat-file', '-e', sha + '^{commit}').returncode:
        st = {'state': 'absent', 'branches': []}
    elif git('merge-base', '--is-ancestor', sha, MAIN).returncode == 0:
        st = {'state': 'on-main', 'branches': ['main']}
    else:
        br, tg, pr = host_contains(sha)
        br = [b for b in br if b != 'main']
        if br:
            st = {'state': 'branch-only', 'branches': br, 'tags': tg, 'pull_refs': pr}
        elif tg:
            st = {'state': 'tag-only', 'branches': [], 'tags': tg, 'pull_refs': pr}
        elif pr:
            st = {'state': 'pull-ref-only', 'branches': [], 'tags': [], 'pull_refs': pr}
        else:
            how = fetched.get(sha)
            st = {'state': 'host-unreferenced', 'branches': [], 'tags': [], 'pull_refs': [],
                  'host_served_by_sha': how or 'not recorded',
                  'note': 'reachable from no branch, tag or pull head ref on the host at %s' % HOST_TIME}
    _reach[sha] = st
    return st
def loc(l):
    f, n = l['location'].rsplit(':', 1)
    return {'file': f, 'line': int(n), 'class': None, 'rule': 'outside-rule-R'}
by_run = collections.defaultdict(list)
for r in refs:
    if r['kind'] == 'run': by_run[r['id']].append({**r, 'rule': 'rule-R'})
rule_r_runs, rule_r_jobs = set(by_run), {r['id'] for r in refs if r['kind'] == 'job'}
out_run = {k: [loc(l) for l in v] for k, v in outside['runs_new'].items()}
for k, v in out_run.items():
    assert k not in by_run, k
    by_run[k].extend(v)
for k, v in outside['runs_also_rule_r'].items():  # further citing lines of ids rule R already counts
    assert k in rule_r_runs, k
    by_run[k].extend(loc(l) for l in v)
# a run cited only inside a stated range of consecutive runs (range.json): kept apart, its own label
rng = L('range.json')
range_runs = {}
for g in rng['ranges']:
    for k in g['inner_runs']:
        assert k not in by_run and k in runs, k
        range_runs[k] = [{'file': g['location'].rsplit(':', 1)[0], 'line': int(g['location'].rsplit(':', 1)[1]), 'class': None,
                          'rule': 'range'}]
for k, v in range_runs.items():
    by_run[k].extend(v)
job_cites = collections.defaultdict(list)
for r in refs:
    if r['kind'] == 'job': job_cites[r['id']].append({**r, 'rule': 'rule-R'})
out_job = {k: [loc(l) for l in v['locations']] for k, v in outside['job_shaped'].items() if not v['also_rule_r']}
for k, v in out_job.items():
    assert k in jobs and k not in job_cites, k
    job_cites[k].extend(v)
for k, v in outside['job_shaped'].items():
    if v['also_rule_r']:
        assert k in rule_r_jobs, k
        job_cites[k].extend(loc(l) for l in v['locations'])
jobs_of_run = collections.defaultdict(list)
for j, v in jobs.items():
    if v.get('run_id'): jobs_of_run[str(v['run_id'])].append((j, v.get('name')))
def age_exp(created):
    if not created: return None, None
    t = dt.datetime.fromisoformat(created.replace('Z', '+00:00'))
    return (NOW - t).days, (t + dt.timedelta(days=90)).date().isoformat()
rows = []
for rid in sorted(set(by_run) | {str(v['run_id']) for v in jobs.values() if v.get('run_id')}):
    m, cs = runs.get(rid), by_run.get(rid, [])
    roles = sorted({role(r['file']) for r in cs})
    tier = 'J' if not cs else ('A' if set(roles) & {'result', 'receipt', 'certificate'} else ('B' if set(roles) & {'preregistration', 'amendment'} else 'C'))
    age, exp = age_exp(m and m.get('created_at'))
    lg = logs.get(rid) or {}
    cj = sorted(jobs_of_run.get(rid, []))
    byt = ('raw-log-bytes' if rid in raw_runs else 'expected-result-only' if rid in covered else 'none')
    rows.append({
        'run_id': rid, 'cited_directly': bool(cs),
        'cited_by': (('rule-R' if any(r['rule'] == 'rule-R' for r in cs) else 'outside-rule-R' if any(r['rule'] == 'outside-rule-R' for r in cs)
                      else 'range-only') if cs else 'job-only'),
        'citing_lines_by_rule': dict(collections.Counter(r['rule'] for r in cs)),
        'r1_entry': 'ci-' + rid if rid in ci_entries else ('bg3' if rid in derived_runs else None),
        'tier': tier, 'created_at': m and m.get('created_at'), 'age_days': age, 'expiry_if_90_day_default': exp,
        'state_1_metadata': {'live': m is not None, 'archived_by_r1': rid in archived_meta},
        'state_2_logs': {'status': lg.get('logs', 'not-checked'), 'detail': lg.get('detail', ''), 'checked_at': lg.get('checked_at')},
        'state_3_bytes': {'status': byt, **({'raw': raw_runs[rid]} if rid in raw_runs else {})},
        'state_4_commit': {'head_sha': m and m.get('head_sha'), **commit_state(m and m.get('head_sha'))},
        'workflow': m and m.get('path'), 'event': m and m.get('event'), 'conclusion': m and m.get('conclusion'),
        'head_branch': m and m.get('head_branch'),
        'citing_roles': roles, 'citing_classes': sorted({r['class'] for r in cs if r['class']}), 'citations': len(cs),
        'citing_files': len({r['file'] for r in cs}), 'locations': ['%s:%d' % (r['file'], r['line']) for r in cs],
        'cited_jobs': [{'job_id': j, 'name': n} for j, n in cj],
    })
order = {'A': 0, 'B': 1, 'J': 2, 'C': 3}
rows.sort(key=lambda r: (r['r1_entry'] is not None, order[r['tier']], r['created_at'] or ''))
jrows = []
for j in sorted(job_cites):
    v = jobs.get(j, {})
    rid = str(v['run_id']) if v.get('run_id') else None
    jrows.append({'job_id': j, 'cited_by': 'rule-R' if any(r['rule'] == 'rule-R' for r in job_cites[j]) else 'outside-rule-R', 'run_id': rid, 'name': v.get('name'), 'workflow_name': v.get('workflow_name'),
                  'conclusion': v.get('conclusion'), 'started_at': v.get('started_at'), 'request_error': v.get('error'),
                  'run_cited_directly': rid in by_run if rid else None, 'run_r1_entry': (rid in covered) if rid else None,
                  'logs_of_run': (logs.get(rid) or {}).get('logs', 'not-checked') if rid else None,
                  'bytes': ({'status': 'raw-log-bytes', **raw_jobs[j]} if j in raw_jobs else
                            {'status': 'expected-result-only'} if j in derived_jobs else {'status': 'none'}),
                  'citations': len(job_cites[j]), 'locations': ['%s:%d' % (r['file'], r['line']) for r in job_cites[j]]})
C = collections.Counter
unc = [r for r in rows if r['r1_entry'] is None and r['cited_directly']]
summary = {
    'generated_at': NOW.isoformat(timespec='seconds'), 'main': MAIN,
    'citation_rule': 'the off-main audit rule R at fc5abade (verification/audits/evidence-retention/audit/offmain_audit.py), '
                     'excluding ids that sit inside a longer hex token',
    'audit_figures': {'historical_audit_output': {'citations': len(raw_refs), 'run_ids': len({r['id'] for r in raw_refs if r['kind'] == 'run'}),
                                                  'job_ids': len({r['id'] for r in raw_refs if r['kind'] == 'job'})},
                      'corrected': {'citations': len(refs), 'locations': len({(r['file'], r['line']) for r in refs}),
                                    'run_ids': len(rule_r_runs), 'job_ids': len(rule_r_jobs)},
                      'excluded_hex_fragments': [{'id': r['id'], 'location': '%s:%d' % (r['file'], r['line'])} for r in excluded]},
    'r1_coverage': {'ci_entries': len(ci_entries), 'runs_covered_only_by_bg3_entries': sorted(derived_runs - ci_entries),
                    'runs_with_any_r1_file': len(covered & set(by_run)), 'runs_with_raw_log_bytes': sorted(raw_runs),
                    'note': '96 ci-<run> entries hold an expected result and run record each; BG-3 entries add three more runs; '
                            'raw log bytes are held for four runs only, three of them as served tails of at most 5000 lines'},
    'beyond_rule_r': {'rule': outside['rule'], 'commit': outside['commit'],
                      'runs': sorted(out_run), 'jobs': sorted(out_job),
                      'further_lines_for_rule_r_runs': sum(len(v) for v in outside['runs_also_rule_r'].values()),
                      'further_lines_for_rule_r_jobs': sum(len(v['locations']) for v in outside['job_shaped'].values() if v['also_rule_r']),
                      'note': 'cited runs and jobs whose citing lines lack the words run, job and actions/, so rule R does not count '
                              'them; they are inventoried here and do not change the audit figures above, which are rule R\'s'},
    'counts': {'runs': len(rows), 'runs_cited_directly': len(by_run), 'runs_cited_by_rule_r': sum(1 for r in rows if r['cited_by'] == 'rule-R'),
               'runs_cited_only_outside_rule_r': sum(1 for r in rows if r['cited_by'] == 'outside-rule-R'),
               'runs_cited_only_by_range': sum(1 for r in rows if r['cited_by'] == 'range-only'),
               'jobs_cited_by_rule_r': sum(1 for j in jrows if j['cited_by'] == 'rule-R'),
               'jobs_cited_only_outside_rule_r': sum(1 for j in jrows if j['cited_by'] == 'outside-rule-R'), 'runs_only_via_jobs': sum(1 for r in rows if not r['cited_directly']),
               'uncovered_cited_runs': len(unc), 'jobs': len(jrows)},
    'uncovered': {'by_tier': dict(C(r['tier'] for r in unc)), 'by_logs': dict(C(r['state_2_logs']['status'] for r in unc)),
                  'by_commit': dict(C(r['state_4_commit']['state'] for r in unc)), 'by_workflow': dict(C(r['workflow'] for r in unc)),
                  'by_event': dict(C(r['event'] for r in unc)),
                  'oldest': min(((r['created_at'], r['run_id']) for r in unc if r['created_at']), default=None)},
    'all_runs': {'by_logs': dict(C(r['state_2_logs']['status'] for r in rows)), 'by_bytes': dict(C(r['state_3_bytes']['status'] for r in rows)),
                 'by_commit': dict(C(r['state_4_commit']['state'] for r in rows))},
    'jobs': {'by_request': dict(C('error' if j['request_error'] else 'ok' for j in jrows)),
             'runs_they_belong_to': len({j['run_id'] for j in jrows if j['run_id']}),
             'in_runs_not_cited_directly': sum(1 for j in jrows if j['run_id'] and not j['run_cited_directly']),
             'by_name': dict(C(j['name'] for j in jrows))},
    'retention': {'setting': 'not readable with the available tools; provisional',
                  'canary': 'run 32881398793, created 2026-08-25, the oldest run in the repository; its logs were served on 2026-10-16',
                  'lower_bound_days': 52, 'note': 'the bound shows that one 52-day-old log was available; it does not establish the '
                  'setting or guarantee any other run. Under the 90-day default the oldest cited run would expire about 2026-12-17.'},
    'tier_rule': TIER_RULE + ' Every known citing line counts toward the tier, whichever scan found it.',
    'ranges': rng,
    'r3': {'decision': 'resolved by preservation, not by code change',
           'reason': 'OI-CHANNEL-1 frozen controls pin the sha256 of verification/lean/oi_channel1_check.py; a docstring-only edit '
                     'makes the controls self-test fail with P on every CI run, while the checker output is unchanged',
           'commits_to_preserve': {c: commit_state(c) for c in ('78aa5b25415cf1cd26994cb2280343ab86cd72d9', 'e7d380fcb9881e3063243aaa149e85be3cd0a914')}},
}
json.dump({'summary': summary, 'runs': rows, 'jobs': jrows}, open(os.path.join(inv, 'inventory.json'), 'w'), indent=1)
with open(os.path.join(inv, 'inventory-runs.csv'), 'w', newline='') as fh:
    w = csv.writer(fh)
    w.writerow(['run_id', 'cited_by', 'r1_entry', 'tier', 'created_at', 'age_days', 'expiry_if_90_day_default', 'metadata_live',
                'metadata_archived_by_r1', 'logs', 'bytes', 'commit', 'commit_branches', 'commit_tags', 'commit_pull_refs', 'head_sha', 'workflow', 'event',
                'conclusion', 'citations', 'citing_files', 'citing_roles', 'cited_job_names'])
    for r in rows:
        w.writerow([r['run_id'], r['cited_by'], r['r1_entry'] or '', r['tier'], r['created_at'], r['age_days'], r['expiry_if_90_day_default'],
                    r['state_1_metadata']['live'], r['state_1_metadata']['archived_by_r1'], r['state_2_logs']['status'],
                    r['state_3_bytes']['status'], r['state_4_commit']['state'], ';'.join(r['state_4_commit']['branches']),
                    ';'.join(r['state_4_commit'].get('tags', [])), ';'.join(r['state_4_commit'].get('pull_refs', [])),
                    r['state_4_commit']['head_sha'], r['workflow'], r['event'], r['conclusion'], r['citations'], r['citing_files'],
                    ';'.join(r['citing_roles']), ';'.join(sorted({j['name'] or '?' for j in r['cited_jobs']}))])
with open(os.path.join(inv, 'inventory-jobs.csv'), 'w', newline='') as fh:
    w = csv.writer(fh)
    w.writerow(['job_id', 'cited_by', 'run_id', 'name', 'conclusion', 'started_at', 'request_error', 'run_cited_directly', 'run_r1_entry', 'logs_of_run', 'bytes', 'citations'])
    for j in jrows:
        w.writerow([j['job_id'], j['cited_by'], j['run_id'], j['name'], j['conclusion'], j['started_at'], j['request_error'] or '',
                    j['run_cited_directly'], j['run_r1_entry'], j['logs_of_run'], j['bytes']['status'], j['citations']])
print(json.dumps(summary, indent=1))
