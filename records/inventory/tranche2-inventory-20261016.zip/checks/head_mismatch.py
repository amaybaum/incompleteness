"""For every line at COMMIT that names a listed run id and one or more 40-hex tokens, classify each token against the
run's head_sha from the run listing: equal; prefix-collision (same first 8 hex, different full id); or other.
Prefix-collisions are tokens that look like the run's head but are not. Usage: head_mismatch.py COMMIT RUNS.json OUT.json"""
import json, re, subprocess, sys
C, R, OUT = sys.argv[1:4]
G = ['git', '-C', '/home/user/incompleteness']
runs = json.load(open(R))
skip = ('.pdf', '.tex', '.olean', '.png', '.jpg', '.gz', '.zip', '.ilean', '.bundle', '.log')
files = [f for f in subprocess.run(G + ['ls-tree', '-r', '--name-only', C], capture_output=True, text=True, check=True).stdout.split('\n') if f and not f.endswith(skip)]
rid = re.compile(r'(?<![0-9A-Za-z.])(3\d{10})(?![0-9A-Za-z])')
hx = re.compile(r'(?<![0-9a-fA-F])([0-9a-f]{40})(?![0-9a-fA-F])')
res = {'commit': C, 'equal': 0, 'prefix_collisions': [], 'other_tokens_on_run_lines': 0, 'lines_checked': 0}
for f in files:
    t = subprocess.run(G + ['show', C + ':' + f], capture_output=True).stdout.decode('utf-8', 'replace')
    for i, line in enumerate(t.split('\n'), 1):
        ids = [m for m in rid.findall(line) if m in runs]
        toks = hx.findall(line)
        if not ids or not toks: continue
        res['lines_checked'] += 1
        heads = {k: runs[k]['head_sha'] for k in ids}
        for tok in toks:
            if tok in heads.values(): res['equal'] += 1; continue
            hit = [k for k, h in heads.items() if h[:8] == tok[:8]]
            if hit:
                res['prefix_collisions'].append({'location': f'{f}:{i}', 'token': tok, 'run': hit[0], 'run_head': heads[hit[0]]})
            else:
                res['other_tokens_on_run_lines'] += 1
json.dump(res, open(OUT, 'w'), indent=1)
print('lines', res['lines_checked'], 'equal', res['equal'], 'other', res['other_tokens_on_run_lines'], 'prefix-collisions', len(res['prefix_collisions']))
for p in res['prefix_collisions']: print(' ', p['location'], p['token'], 'run', p['run'], 'real', p['run_head'])
