# Thread C5 (BRIDGE-COUNTER), stage 5 (relaunch) — running notes

All clock times below are read from `date -u`; none are estimated.

## N0 — start (2026-10-10T16:45:05Z)

- `pt/C5/` did not exist at launch (checked 16:44:45Z); created at 16:44:59Z; `.start_marker` written first
  (utc_start 2026-10-10T16:44:59Z).
- Start checks (recorded in full in `.start_marker`): six manifests verify from `pt/` (rc=0 each);
  `audit/stage3-inputs/ns.manifest.sha256` verifies from its own directory (`ns/NS-INPUT.md: OK`, nothing else
  read there); `pt/base` HEAD = 9f9f8257a980a1819fbbc1dc0019917cf8678626, `status --porcelain` empty, no
  `__pycache__`/`.pyc` under `pt/base/`; nine protocol files with the required sha256 prefixes and all nine
  sidecars verify (STAGE4/STAGE5/STAGE5-AMENDMENT-1 from SCRATCH, others from `pt/`); `pt/` top-level listing
  with mtimes recorded. All start checks pass.
- Governing texts: `PROTOCOL-STAGE5.md` (9e01f098…) and `PROTOCOL-STAGE5-AMENDMENT-1.md` (1f639115…) read in full
  at 16:45Z. Working directory `pt/C5/`; sibling `pt/D5/` never read.
