# Thread D5 (BRIDGE-DERIVE) — stage 5 — running record

All clock times are UTC read from `date -u` at the moment of writing; none is estimated.

## N0 — start (16:44:15Z – 16:44:56Z)

- 16:44:07Z `pt/D5/` checked absent; created 16:44:15Z.
- Start checks (full output in `.start_marker`, assembled 16:44:35Z): 6/6 manifests OK
  (`inputs`, `stage1`, `inputs2`, `inputs3`, `stage2`, `inputs4`); `audit/stage3-inputs/ns.manifest.sha256`
  OK from its own directory (one line, `ns/NS-INPUT.md: OK`; nothing else read there); base HEAD
  `9f9f8257a980a1819fbbc1dc0019917cf8678626`, `status --porcelain` empty, no `__pycache__`/`.pyc` under
  `pt/base/`; the nine protocol files carry the expected sha256 prefixes and all nine sidecars verify
  (STAGE4, STAGE5, STAGE5-AMENDMENT-1 from SCRATCH; the other six from `pt/`); `pt/` top-level listing with
  mtimes recorded.
- Process deviation, recorded: `.start_marker` was written as two part files (`.start_marker.part1`,
  `.start_marker.part2`, both inside `pt/D5/`) and concatenated into `.start_marker` at 16:44:35Z; the parts were
  then removed. A transient `pt/D5/.chk` (capture of `sha256sum -c --quiet`) was created and removed during
  check (1). No file outside `pt/D5/` was written. `pt/C5/` did not exist at 16:44:07Z.
- Governing texts read in full, 16:44:40Z–16:44:56Z: `PROTOCOL-STAGE5.md`, `PROTOCOL-STAGE5-AMENDMENT-1.md`
  (working directory `pt/D5/`; sibling `pt/C5/`, never read), then `PROTOCOL-STAGE4.md`, `PROTOCOL-STAGE3.md`,
  `PROTOCOL-STAGE2.md`, `PROTOCOL.md`, `PROTOCOL-AMENDMENT-1.md`, `PROTOCOL-AMENDMENT-2.md`,
  `PROTOCOL-STAGE2-DS.md`.
- Prescribed records read 16:44:56Z–16:46:20Z, in order: `INTEGRATION-NOTE-STAGE4.md`, `audit/Y/AUDIT-Y.md`,
  `audit/Z/AUDIT-Z.md`, `Y/RESULT.md`, `Z/RESULT.md`, `INTEGRATION-NOTE-STAGE3.md`; ledgers `EQ2-SYNTHESIS.md`,
  `EQ3-P-RESULT.md`, `EQ3-AUDIT.md`, `EQ5-SOURCE-RESULT.md`, `EQ5-SOURCE-AUDIT.md`; the certified premise audit
  `round-kt4-prem-1-premise-audit/result.md`; `pt/base/AGENTS.md` (code-review rules :41–94, §A.31 :306–342,
  §A.21 :436–438). Not read: `pt/C5/`, `audit/stage3-inputs/OWNER-*`, `audit/stage4-inputs/OWNER-*`,
  `audit/stage5-inputs/`, `audit/reviews/`, `audit/aborted-launches/`.

## N0.1 — productivity test and plan (fixed 16:46:23Z, before the first node)

**Productivity test (§A.31, fixed now).** A node's finding is a gem iff it is strictly stronger than the obvious
restatement — the obvious restatement here being "the spectator clause is a hypothesis, so the bridge is
CONDITIONAL on it", which the protocol already says — AND it is one of: (1) an exact certificate at a stated
instance (a derivation with every step checked, or an exact countermodel with the candidate's transcription
verified exactly); (2) an exact obstruction for a stated class of routes (e.g. every principle stated on
single-token data alone, or every principle below the OI⁺ layer at L); (3) an exposed hidden assumption (a
kernel definition or manuscript sentence whose content differs from what the chain L0–L3 attributes to it, with
file:line). Otherwise record-only. Propagation bar: better than coherence relabelling.

**Decision rules for verdicts (fixed now).** DERIVED(P) only with [W + X] proof, P passing the disguise test, and a
recorded pressure test of the favourable branch. INDEPENDENT(P) only with an exact structure verified to satisfy P's
transcription, H1–H3 and the certified single-token structure, cone ≠ Q3 — or a kernel theorem cited with scope.
CONDITIONAL(P; A) with A named, A's status and A's disguise result. A failed derivation alone is UNRESOLVED, never
INDEPENDENT (amendment 2). A clause failing the disguise test is never called DERIVED.

**Plan (depth-first; decisive first).**
- N1 — L2 sourcing map at the matrix level (decides the shape of every verdict): read and quote at L the
  definitions and theorems the protocol names (ReferenceExtension, CompletedOI, ImplementationLocality,
  StructuralClosure, LiftAudit, DerivedQ3, ExecSource, ReadWriteControl, SubstratumInterface; GR.md, Main.md,
  ROADMAP). Sub-nodes: N1a which spectator clauses are theorems of the substratum class; N1b which are hypotheses
  of an extension; N1c whether `LayerFlowExecutable` at level 1 plus implementation locality /
  `HasParallelReferenceExtension` gives every level; N1d what `ImplementationLocality` (:370) says and what
  `observationalIndependence_of_implementationLocality` (:957) needs.
- N2 — candidates α, β, γ, δ: field-neutral transcription to the pair setting (W 3, K with H1–H3, actC/actT,
  body, NOT, flow, J); derivation attempt for (b_min); disguise test; outcome.
- N3 — candidates ε, ζ, λ, same treatment.
- N4 — exact scripts (python3 -I -B, sympy/Fractions; decision rule in the header before the first run):
  transcription of the single-token data from the Lean source (cnot, nflip, z3, J = cyc3, the drive's flow);
  the L3 link for the weakest sufficient field-neutral content ((b) for the flow and J; (b) for one off-frame
  rotation) with Q3 retention and stage-3-cone exclusion countercontrols; any exact countermodel a verdict needs
  (the pair-blindness of single-token principles, on K(E0) / K(Z_F)).
- N5 — whether any principle at L below the OI⁺ layer yields L2; weakest sufficient added content in both
  settings; hard-to-vary review; end checks; RESULT.md.
