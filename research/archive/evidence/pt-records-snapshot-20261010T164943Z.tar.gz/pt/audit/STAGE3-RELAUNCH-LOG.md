# Stage-3 relaunch log (coordinator; kept under pt/audit/ so the running thread X does not see a foreign write)

- Thread U launch 1 (10:22Z) was terminated by a tooling error at 2026-10-10 10:24:51Z + reading phase: the agent's response exceeded the 64000-token output maximum (API error max_output_tokens). It had written only pt/U/.start_marker (sha256 674151c0b333ed5f1daf160c8dbf9d20f13da1dbf503ffd6de1e9d2bacfa1b70), moved here as audit/aborted-launches/U-launch1/.start_marker with its mtime preserved. No script, output or result existed.
- 2026-10-10T11:17:06Z: thread U relaunched (launch 2) with the same frozen protocol PROTOCOL-STAGE3.md (1a649168…) and the same inputs; the relaunch prompt adds only a tooling constraint (write files in parts of at most ~250 lines). Thread X was not affected and keeps running.

- Thread X launch 1 (10:22Z) was terminated by the same tooling error (max_output_tokens) at its first step, having written only pt/X/.start_marker (sha256 6243a89ad15ea8cafb88a7dd3617a22c7b86af14785bb38a6b0e91ec657b8166), moved to audit/aborted-launches/X-launch1/ with its mtime preserved.
- 2026-10-10T11:19:34Z: thread X relaunched (launch 2) with the same frozen protocol and inputs; tooling change only: the agent model is pinned to the one stage 2 ran under (Opus), and files are written in parts. Both failures occurred after the session model was switched to Fable 5.1 (subagents inherit it), which is the probable cause; the mathematics and the protocol are unchanged.

- Thread U launch 2 (11:17Z, still under the inherited Fable 5.1 model) was stopped by the coordinator at 11:20Z, before any script, after X's identical failure showed the cause to be the model switch; it had written only pt/U/.start_marker (sha256 3d061fd35e73f4a627c26113a8014bebc30c15a593cdb2ea91569c3289f83101), moved to audit/aborted-launches/U-launch2/ with its mtime preserved.
- 2026-10-10T11:21:12Z: thread U relaunched (launch 3) with the agent model pinned to Opus, as X launch 2; protocol and inputs unchanged.

- 2026-10-10T12:34:09Z: review thread NS launched (one agent, model pinned to Opus, research-only) under PROTOCOL-NS.md sha256 4f61891f82a4bfe13a9d0ed74fd064c903c94d57ed8d29bf039633f72b2494e0; working directory pt/audit/reviews/NS/ (inside the coordinator's area because U and X are running); input ns/NS-INPUT.md sha256 d8c5a1b3da937217f207cad416c6d0d1a59f69ac177cb704274f3956449d98fb.

## Stage 4 launch (Q-EX), 2026-10-10T14:22:11Z
- Stage-3 archive delivered first (evidence/pt-stage3-evidence.tar.gz bc275ae3…, manifest e3d58960…), per owner note 4.
- Protocol: pt/PROTOCOL-STAGE4.md, sha256 d3da28116a5bcdd3…; threads Y (exclusion) and Z (countermodels),
  Opus model, write-in-parts constraint (as the stage-3 relaunches); working directories pt/Y/, pt/Z/; coordinator writes only
  under pt/audit/ while they run.

## Stage 4 close (2026-10-10T16:16Z)
Y reported 15:23Z, audited (AUDIT-Y.md a4d12a39…); Z reported 16:00Z, audited (AUDIT-Z.md 4be00ec5…). Integration note pt/INTEGRATION-NOTE-STAGE4.md written; archive built by drafts/build_stage4_evidence.sh. Holds unchanged.

## Stage 5 launch (Q-EX-BRIDGE), 2026-10-10T16:40:27Z
- Owner note 7 recorded (pt/audit/stage5-inputs/OWNER-NOTE7-STAGE4-CLOSE.md 1436874a…); manuscript obligation M1 recorded, not applied (MANUSCRIPT-OBLIGATIONS.md 3b362615…).
- Protocol: pt/PROTOCOL-STAGE5.md, sha256 9e01f098cbe0a279…, sidecar verifies from the scratchpad directory; coordinator pre-audit PRE-AUDIT-BRIDGE.md with preaudit_bridge.py 7/7 (run 3; runs 1-2 kept), replay identical.
- Threads D (BRIDGE-DERIVE) and C (BRIDGE-COUNTER), Opus model, write-in-parts constraint; working directories pt/D/, pt/C/; coordinator writes only under pt/audit/ while they run. Holds unchanged.
- 16:41Z first launch ABORTED by the threads' own guard: pt/D/ and pt/C/ are the stage-1 records (coordinator error); nothing written; manifests verify (16:42:34Z). Amendment 1 (pt/PROTOCOL-STAGE5-AMENDMENT-1.md 1f639115d369de13…) renames the working directories to pt/D5/ and pt/C5/; record pt/audit/aborted-launches/stage5-launch1.md. Relaunch follows.
- Relaunch: thread D into pt/D5/ at 16:43:4xZ and thread C into pt/C5/ at 2026-10-10T16:44:55Z, both under PROTOCOL-STAGE5.md 9e01f098… + AMENDMENT-1 1f639115… (nine protocol hashes in the brief). First instances D and C both stopped at their guard without writing; C reported at 16:44Z (28 stage-1 files verified by its own check).
